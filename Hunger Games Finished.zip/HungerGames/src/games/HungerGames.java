package games;

import java.util.ArrayList;

/**
 * This class contains methods to represent the Hunger Games using BSTs.
 * Moves people from input files to districts, eliminates people from the game,
 * and determines a possible winner.
 * 
 * @author Pranay Roni
 * @author Maksims Kurjanovics Kravcenko
 * @author Kal Pandit
 */
public class HungerGames {

    private ArrayList<District> districts;  // all districts in Panem.
    private TreeNode            game;       // root of the BST. The BST contains districts that are still in the game.

    /**
     * ***** DO NOT REMOVE OR UPDATE this method *********
     * Default constructor, initializes a list of districts.
     */
    public HungerGames() {
        districts = new ArrayList<>();
        game = null;
        StdRandom.setSeed(2023);
    }

    /**
     * ***** DO NOT REMOVE OR UPDATE this method *********
     * Sets up Panem, the universe in which the Hunger Games takes place.
     * Reads districts and people from the input file.
     * 
     * @param filename will be provided by client to read from using StdIn
     */
    public void setupPanem(String filename) { 
        StdIn.setFile(filename);  // open the file - happens only once here
        setupDistricts(filename); 
        setupPeople(filename);
    }

    /**
     * Reads the following from input file:
     * - Number of districts
     * - District ID's (insert in order of insertion)
     * Insert districts into the districts ArrayList in order of appearance.
     * 
     * @param filename will be provided by client to read from using StdIn
     */
    public void setupDistricts (String filename) {

        if(StdIn.isEmpty()){
            return;
        }
        int numOfDistricts = StdIn.readInt();
        for(int i=0;i<numOfDistricts;i++){
            District newDistrict = new District(StdIn.readInt());
            districts.add(newDistrict);
        }
    }

    /**
     * Reads the following from input file (continues to read from the SAME input file as setupDistricts()):
     * Number of people
     * Space-separated: first name, last name, birth month (1-12), age, district id, effectiveness
     * Districts will be initialized to the instance variable districts
     * 
     * Persons will be added to corresponding district in districts defined by districtID
     * 
     * @param filename will be provided by client to read from using StdIn
     */
    public void setupPeople (String filename) {
        if(StdIn.isEmpty()){
            return;
        }
        int numOfPeople = StdIn.readInt();
        for(int i=0;i<numOfPeople;i++){
            String FirstName = StdIn.readString();
            String LastName = StdIn.readString();
            int birth = StdIn.readInt();
            int age = StdIn.readInt();
            int ID = StdIn.readInt();
            int effect = StdIn.readInt();
            Person subject = new Person(birth, FirstName, LastName, age, ID, effect);
            if(subject.getAge()>=12 && subject.getAge()<=18){
                subject.setTessera(true);
            }else{
                subject.setTessera(false);
            }
            for(int j=0;j<districts.size();j++){
                if(districts.get(j).getDistrictID()==subject.getDistrictID()){
                    if(subject.getBirthMonth()%2==0){
                        districts.get(j).addEvenPerson(subject);
                    }else if(subject.getBirthMonth()%2==1){
                        districts.get(j).addOddPerson(subject);
                    }
                }
            }
        }
    }

    /**
     * Adds a district to the game BST.
     * If the district is already added, do nothing
     * 
     * @param root        the TreeNode root which we access all the added districts
     * @param newDistrict the district we wish to add
     */
    public void addDistrictToGame(TreeNode root, District newDistrict) {
        TreeNode newTree = new TreeNode();
        newTree.setDistrict(newDistrict);
        TreeNode prt1 = new TreeNode();
        prt1=game;

        if(prt1==null){
            game = newTree;
            removeDistrict(newDistrict.getDistrictID());
        }
        while(prt1!=null){
            if(newDistrict.getDistrictID()>prt1.getDistrict().getDistrictID()){
                if(prt1.getRight()==null){
                    prt1.setRight(newTree);
                    removeDistrict(newDistrict.getDistrictID());
                    return;
                }else{
                    prt1=prt1.getRight();
                }
            }else if(newDistrict.getDistrictID()<prt1.getDistrict().getDistrictID()){
                if(prt1.getLeft()==null){
                    prt1.setLeft(newTree);
                    removeDistrict(newDistrict.getDistrictID());
                    return;
                }else{
                    prt1=prt1.getLeft();
                }
            }
        }        
    }

    /**
     * Searches for a district inside of the BST given the district id.
     * 
     * @param id the district to search
     * @return the district if found, null if not found
     */
    public District findDistrict(int id) {
        if(getRoot() == null){
            return null;
        }
        return finderHelper(id, getRoot());
    }

    /**
     * Selects two duelers from the tree, following these rules:
     * - One odd person and one even person should be in the pair.
     * - Dueler with Tessera (age 12-18, use tessera instance variable) must be
     * retrieved first.
     * - Find the first odd person and even person (separately) with Tessera if they
     * exist.
     * - If you can't find a person, use StdRandom.uniform(x) where x is the respective 
     * population size to obtain a dueler.
     * - Add odd person dueler to person1 of new DuelerPair and even person dueler to
     * person2.
     * - People from the same district cannot fight against each other.
     * 
     * @return the pair of dueler retrieved from this method.
     */
    public DuelPair selectDuelers() {
        
        TreeNode root = new TreeNode();
        root = getRoot();
        // WRITE YOUR CODE HERE
        DuelPair VS = new DuelPair();
        tesseraSearch(false, root, VS); //false == odd
        tesseraSearch(true, root, VS); //true == even

        //if there is still empty due to no tessera, random time!
        if(VS.getPerson1()==null){
            NoTesSearch(false, root, VS);
        }
        if(VS.getPerson2()==null){
            NoTesSearch(true, root, VS);
        }
       
        if(VS.getPerson1()!=null){
            findDistrict(VS.getPerson1().getDistrictID()).getOddPopulation().remove(VS.getPerson1());
        }
        if(VS.getPerson2()!=null){
            findDistrict(VS.getPerson2().getDistrictID()).getEvenPopulation().remove(VS.getPerson2());
        }
        
        return VS;
    }


    /**
     * Deletes a district from the BST when they are eliminated from the game.
     * Districts are identified by id's.
     * If district does not exist, do nothing.
     * 
     * This is similar to the BST delete we have seen in class.
     * 
     * @param id the ID of the district to eliminate
     */
    public void eliminateDistrict(int id) {

        // WRITE YOUR CODE HERE
        if (findDistrict(id)==null){
            return;
        }

        //helper method to get a specific node from the tree depending on the ID given.
        TreeNode delete = new TreeNode();
        TreeNode prev = new TreeNode();
        FindNode(id, game, delete, prev);

        int children=0;
        //checks for how many children to found node are there
        if(delete.getLeft()!=null){
            children++;
        }
        if(delete.getRight()!=null){
            children++;
        }
    
        game=DeleteNode(children, game, delete);
    }
        

    /**
     * Eliminates a dueler from a pair of duelers.
     * - Both duelers in the DuelPair argument given will duel
     * - Winner gets returned to their District
     * - Eliminate a District if it only contains a odd person population or even
     * person population
     * 
     * @param pair of persons to fight each other.
     */
    public void eliminateDueler(DuelPair pair) {

        // WRITE YOUR CODE HERE
        if(pair.getPerson1()==null && pair.getPerson2()==null){
            return;
        }
        if(pair.getPerson1()!=null && pair.getPerson2()==null){
            if(pair.getPerson1().getBirthMonth()%2==0){
                findDistrict(pair.getPerson1().getDistrictID()).addEvenPerson(pair.getPerson1());
                return;
            }else if(pair.getPerson1().getBirthMonth()%2==1){
                findDistrict(pair.getPerson1().getDistrictID()).addOddPerson(pair.getPerson1());
                return;
            }
        }else if(pair.getPerson1()==null && pair.getPerson2()!=null){
            if(pair.getPerson2().getBirthMonth()%2==0){
                findDistrict(pair.getPerson2().getDistrictID()).addEvenPerson(pair.getPerson2());
                return;
            }else if(pair.getPerson2().getBirthMonth()%2==1){
                findDistrict(pair.getPerson2().getDistrictID()).addOddPerson(pair.getPerson2());
                return;
            }
        }

        if(pair.getPerson1()!=null && pair.getPerson2()!=null){
            Person winner = pair.getPerson1().duel(pair.getPerson2());
            if(winner.getBirthMonth()%2==0){
                findDistrict(winner.getDistrictID()).addEvenPerson(winner);
            }else if(winner.getBirthMonth()%2==1){
                findDistrict(winner.getDistrictID()).addOddPerson(winner);
            }
        }
        
        District district1 = findDistrict(pair.getPerson1().getDistrictID());
        District district2 = findDistrict(pair.getPerson2().getDistrictID());
        if (district1.getEvenPopulation().size()==0 || district1.getOddPopulation().size()==0){
            eliminateDistrict(district1.getDistrictID());
        }
        if(district2.getEvenPopulation().size()==0 || district2.getOddPopulation().size()==0){
            eliminateDistrict(district2.getDistrictID());
        }

    }

    /**
     * ***** DO NOT REMOVE OR UPDATE this method *********
     * 
     * Obtains the list of districts for the Driver.
     * 
     * @return the ArrayList of districts for selection
     */
    public ArrayList<District> getDistricts() {
        return this.districts;
    }

    /**
     * ***** DO NOT REMOVE OR UPDATE this method *********
     * 
     * Returns the root of the BST
     */
    public TreeNode getRoot() {
        return game;
    }

    private void removeDistrict(int id){
        for(int i=0; i<districts.size();i++){
            if(districts.get(i).getDistrictID()==id){
                districts.remove(districts.get(i));
            }
        }
    }

    private District finderHelper(int id,TreeNode root){
        if(root == null){
            return null;
        }
        if(root.getDistrict().getDistrictID()==id){
            return root.getDistrict();
        }
        if(root.getDistrict().getDistrictID()<id){
            return(finderHelper(id, root.getRight()));
        }if(root.getDistrict().getDistrictID()>id){
            return(finderHelper(id, root.getLeft()));
        }
        return null;
    }

    private void tesseraSearch(boolean side, TreeNode root, DuelPair pair){
        if(root == null){
            return;
        }
        if(side==false){ //odd population
            if(root.getDistrict().getOddPopulation().size()!=0){ //if the odd population isnt empty,
                for(int i=0;i<root.getDistrict().getOddPopulation().size();i++){ //go through to see if someone is tessera.
                    if(root.getDistrict().getOddPopulation().get(i).getTessera()==true){ //if there is one, return the first.
                        pair.setPerson1(root.getDistrict().getOddPopulation().get(i)); //this ends the function.
                        return;
                    }
                }
            }
        }else if(side==true){ //same as before, but for even.
            if(root.getDistrict().getEvenPopulation()!=null){
                for(int i=0;i<root.getDistrict().getEvenPopulation().size();i++){
                    if(pair.getPerson1()!=null){//if there is someone from odd pop already chosen
                        if(root.getDistrict().getDistrictID()!=pair.getPerson1().getDistrictID()){//check if their districts dont match
                            if(root.getDistrict().getEvenPopulation().get(i).getTessera()==true){
                                pair.setPerson2(root.getDistrict().getEvenPopulation().get(i));
                                return;
                            }
                        }
                    }else if(pair.getPerson1()==null){ //if there isnt
                        if(root.getDistrict().getEvenPopulation().get(i).getTessera()==true){
                            pair.setPerson2(root.getDistrict().getEvenPopulation().get(i));
                            return;
                        }
                    }
                }
            }
        }
        
        //traversal down
        if(root.getLeft()==null && root.getRight()==null){
            return;
        }if(root.getLeft()!=null){
            tesseraSearch(side, root.getLeft(), pair);
        }if(root.getRight()!=null){
            tesseraSearch(side, root.getRight(), pair);
        }
        return;
    }

    private void NoTesSearch(boolean side, TreeNode root, DuelPair pair){
        if(root == null){
            return;
        }

        if(side==false){
            if(root.getDistrict().getOddPopulation().size()!=0){
                if(pair.getPerson2()!=null){
                    if(root.getDistrict().getDistrictID()!=pair.getPerson2().getDistrictID()){
                        int popSize = root.getDistrict().getOddPopulation().size();
                        pair.setPerson1(root.getDistrict().getOddPopulation().get(StdRandom.uniform(popSize)));
                        return;
                    }
                }else if(pair.getPerson2()==null){
                     int popSize = root.getDistrict().getOddPopulation().size();
                     pair.setPerson1(root.getDistrict().getOddPopulation().get(StdRandom.uniform(popSize)));
                     return;
                }
            }
        }else if(side==true){
            if(root.getDistrict().getEvenPopulation().size()!=0){
                if(pair.getPerson1()!=null){
                    if(root.getDistrict().getDistrictID()!=pair.getPerson1().getDistrictID()){
                        int popSize = root.getDistrict().getEvenPopulation().size();
                        pair.setPerson2(root.getDistrict().getEvenPopulation().get(StdRandom.uniform(popSize)));
                        return;
                    }
                }else if(pair.getPerson1()==null){
                    int popSize = root.getDistrict().getEvenPopulation().size();
                    pair.setPerson2(root.getDistrict().getEvenPopulation().get(StdRandom.uniform(popSize)));
                    return;
                }

            }
        }
        
        if(root.getLeft()==null && root.getRight()==null){
            return;
        }if(root.getLeft()!=null){
            NoTesSearch(side, root.getLeft(), pair);
        }if(root.getRight()!=null){
            NoTesSearch(side, root.getRight(), pair);
        }
        return;
    }

    private void FindNode(int id, TreeNode root, TreeNode Found, TreeNode parent){
        if(root==null){
            return;
        }
        //Setting parent's paramaters based on future call if matching.
        if(root.getLeft()!=null && root.getLeft().getDistrict().getDistrictID()==id){
            parent.setDistrict(root.getDistrict());
            parent.setLeft(root.getLeft());
            parent.setRight(root.getRight());
        }
        if(root.getRight()!=null && root.getRight().getDistrict().getDistrictID()==id){
            parent.setDistrict(root.getDistrict());
            parent.setLeft(root.getLeft());
            parent.setRight(root.getRight());
        }

        if(root.getDistrict().getDistrictID()==id){ //If node at point == id inputted, make found equal the node at point. 
            Found.setDistrict(root.getDistrict());
            Found.setLeft(root.getLeft());
            Found.setRight(root.getRight());
            return;
        }

        //Recursion Loop to Search Tree.
        if(root.getLeft()==null && root.getRight()==null){
            return;
        }
        if(root.getLeft()!=null){
            FindNode(id, root.getLeft(), Found, parent);
        }
        if(root.getRight()!=null){
            FindNode(id, root.getRight(), Found, parent);
        }
    
        return;
    }

    private TreeNode DeleteNode(int children, TreeNode root, TreeNode Delete){
        if(root==null){
            return null;
        }
        int compare = Delete.getDistrict().getDistrictID()-root.getDistrict().getDistrictID();
        if(compare<0){
            root.setLeft(DeleteNode(children,root.getLeft(),Delete));
        }else if(compare>0){
            root.setRight(DeleteNode(children,root.getRight(),Delete));
        }else{
            if(root.getRight()==null){
                return root.getLeft();
            }
            if(root.getLeft()==null){
                return root.getRight();
            }

            TreeNode successor = root;
            root = findMinDistrict(successor.getRight());
            root.setRight(DeleteMin(successor.getRight()));
            root.setLeft(successor.getLeft());
        }        
        return root;
    }

    private TreeNode findMinDistrict(TreeNode root){
        if(root.getDistrict()==null){
            return null;
        }
        if(root.getLeft()!=null){
            findMinDistrict(root.getLeft());
        }
        if(root.getLeft()==null){
            return root;
        }
        return root;
    }

    private TreeNode DeleteMin(TreeNode root){
        if(root.getLeft()==null){
            return root.getRight();
        }
        root.setLeft(DeleteMin(root.getLeft()));
        return root;
    }
}