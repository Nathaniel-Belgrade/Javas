import java.util.Scanner;
public class Main{
/*** @param args the command line arguments*/
  public static void main(String[] args) {
  Scanner reader=new Scanner(System.in);
  Patron p=new Patron("Nathaniel");
  int i=0;
  while (true){
    System.out.println("1. My borrowed books 2. Returning a book 3. Borrow a book 4. Find a book 5. Print");
    System.out.println("Choice:");
    i = reader.nextInt();      
      if (i == 1){
        System.out.println("You picked My borrowed books");
        System.out.println("Please enter the author:");
        String author=reader.nextLine();
        author=reader.nextLine();
        System.out.println("please enter the Title:");
        String title=reader.nextLine();
        boolean result=p.hasBorrowed(title,author);
        if(result==true){
          System.out.println("You do have a book with that title and author");
        }else{
          System.out.println("You don't have a book with that author and title");
        }
      }else if (i == 2){
        System.out.println("You picked Returning a book");
        System.out.println("Who is the author?");
        String author=reader.nextLine();
        author=reader.nextLine();
        System.out.println("What is the title?");
        String title=reader.nextLine();
        boolean result=p.returnBook(title,author);
        if(result==true){
          System.out.println("You returned a book, the spot is open");
        }else{
          System.out.println("You do not have that book out in the first place!");
        }
      }else if (i == 3){
        System.out.println("You picked Borrow a book");
        System.out.println("who is the author?");
        String author=reader.nextLine();
        author=reader.nextLine();
        System.out.println("What is the title?");
        String title=reader.nextLine();
        boolean result=p.borrowBook(title,author);
        if(result==true){
          System.out.println("You have borrowed that book!");
        }else{
          System.out.println("You don't have any room to borrow that book");
        }
      }else if(i==4){
        System.out.println("You picked Find a book");
        System.out.println("from 1-3, which slot do you want to check?");
        int n=reader.nextInt();
        String result=p.find(n);
        System.out.println(result);
      }else if(i==5){
        System.out.println("You picked Print");
        System.out.println(p);
      }
    }
  }
}