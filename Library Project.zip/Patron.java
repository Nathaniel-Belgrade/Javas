//second class
public class Patron {
private String name="";
private Book book1=null;
private Book book2=null;
private Book book3=null;
        
public Patron(String name)
{
  this.name=name;
}
public boolean hasBorrowed(String title, String author){
	//Check each book to see if its not equal to null and its title is title, and its author is author.  If any are true, return true, otherwise return false
  if (book1!=null && book1.getTitle().equals(title) && book1.getAuthor().equals(author)){
    return true;
  }else if(book2!=null && book2.getTitle().equals(title)&& book2.getAuthor().equals(author)){
    return true;
  }else if(book3!=null && book3.getTitle().equals(title)&& book3.getAuthor().equals(author)){
    return true;
  }else{
    return false;
  }
} 
public boolean returnBook(String title, String author){
	//Check each book to see if its not equal to null and its title is title, and its author is author.  If any are true, set that book to null and return true, otherwise return false
  if(book1!=null && book1.getTitle().equals(title)&& book1.getAuthor().equals(author)){
    book1=null;
    return true;
  }else if(book2!=null && book2.getTitle().equals(title)&& book2.getAuthor().equals(author)){
    book2=null;
    return true;
  }else if(book3!=null && book3.getTitle().equals(title)&& book3.getAuthor().equals(author)){
    book3=null;
    return true;
  }else{
    return false;
  }
}
public boolean borrowBook(String title, String author){
	//Check for an open spot by seeing if any of the books are equal to null.  When you find one, create a new book in that spot.  For example, if book1 was free, book1=new Book(title,author)
  if(book1==null){
    book1=new Book(title, author);
    return true;
  }else if(book2==null){
    book2=new Book(title, author);
    return true;
  }else if(book3==null){
    book3=new Book(title, author);
    return true;
  }else{
    System.out.println("You can't borrow any more books");
    return false;
  }
}	 
public String find(int n){
	//N represents the number of the book you are returning.  For example, if n is equal to 1 and book1 is not null, then return a string containing the title and author
	//Example return string: Java Rules by Mr. Reilly.  If none are found return the empty string.
  if (n==1 && book1!=null){
    return(book1.getTitle() + " by "+ book1.getAuthor());
  }else if(n==2 && book2!=null){
    return(book2.getTitle() + " by " +book2.getAuthor());
  }else if(n==3 && book3!=null){
    return(book3.getTitle() + " by "+ book3.getAuthor());
  }else{
    return("no book found");
  }
}
	
public String toString()
{      
	//Create a string containing all of the information about each book.  If any spots are empty just return "empty" for that spot
	//Example: Java Rocks by Mr. Reilly
	//	  Empty
	//	  Empty
  String result ="";
  if (book1!=null){
    result=result+book1.getTitle() + " by "+ book1.getAuthor()+"\n";
  }else{
    result=result+"Empty \n";
  }
  if(book2!=null){
    result=result+book2.getTitle() + " by "+ book2.getAuthor()+"\n";
  }else{
    result=result+"Empty \n";
  }
  if (book3!=null){
    result=result+book3.getTitle() + " by "+ book3.getAuthor()+"\n";
  }else{
    result=result+"Empty \n";
  }
  return(result);
}
}