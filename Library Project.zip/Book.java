//third class
public class Book{

private String author;
private String title;

public Book(String title, String author){
  this.title=title;
  this.author=author;
}
//accessor and mutator for title
public String getTitle(){
  return title;
}
public void setTitle(String title){
  this.title=title;
}
//accessor and mutator for author
public String getAuthor(){
  return author;
}
public void setAuthor(String author){
  this.author=author;
}

public String toString(){
  return("The title of the book is " + title + ", written by "+ author + ".");
}
}