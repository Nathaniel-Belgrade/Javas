public class test{
    static final int WET = 1;
    static final int DRY = 2;
    static final int[] numberOfDaysInMonth = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };

  public static void main(String args[]){
    
    double longitude = Double.parseDouble(args[0]);
    double latitude = Double.parseDouble(args[1]);
    double[][] drywet = new double[1400][14];
    double[][] wetwet = new double[1400][14];
    populateArrays(drywet, wetwet);

    double[] drywetProbability = new double[12];
    double[] wetwetProbability = new double[12];
    populateLocationProbabilities(drywetProbability, wetwetProbability, longitude, latitude, drywet, wetwet);

    int[] forecast = forecastGenerator(drywetProbability[3], wetwetProbability[3], numberOfDaysInMonth[3]);
    for(int i=0;i<forecast.length;i++){
      System.out.print(forecast[i]+ ",");
  }
}
    public static void populateArrays(double[][] drywet, double[][] wetwet) {

    StdIn.setFile("drywet.txt");

    for (int i = 0; i < drywet.length; i++) {
      for (int j = 0; j < 14; j++) {
        drywet[i][j] = StdIn.readDouble();
      }
    }

    StdIn.setFile("wetwet.txt");

    for (int i = 0; i < drywet.length; i++) {
      for (int j = 0; j < 14; j++) {
        wetwet[i][j] = StdIn.readDouble();
      }
    }
  }
    public static void populateLocationProbabilities(double[] drywetProbability, double[] wetwetProbability,
      double longitude, double latitude, double[][] drywet, double[][] wetwet) {

    for(int i=0; i<drywet.length; i++) {
      if(drywet[i][0]==longitude && drywet[i][1]==latitude){
        for(int j=0;j<12;j++){
          drywetProbability[j] = drywet[i][j+2];
          System.out.print(drywetProbability[i]+ ", ");
        }
      System.out.println("");
      }
      if(wetwet[i][0]==longitude && wetwet[i][1]==latitude){
        for(int j=0;j<12;j++) {
          wetwetProbability[j] = wetwet[i][j+2];
          System.out.print(wetwetProbability[i] +", ");
        }
      }
    }
    System.out.println("");
  }

    public static int[] forecastGenerator(double drywetProbability, double wetwetProbability, int numberOfDays) {

    int[] forecast = new int[numberOfDays];
    double day1 = StdRandom.uniform();
    if(day1 < 0.50) {
      forecast[0] = WET;
    }else{
      forecast[0] = DRY;
    }
    
    for(int i=0;i<numberOfDays-1;i++){
      double day = StdRandom.uniform();
      System.out.print(day + ", ");
      if (forecast[i]==WET) {
        if (day <= wetwetProbability){
          forecast[i+1] = WET;
        }else{
          forecast[i+1] = DRY;
        }
      }else if(forecast[i]==DRY){
        if(day <= drywetProbability){
          forecast[i+1] = WET;
        }else{
          forecast[i+1] = DRY;
        }
      }
    }
      
    System.out.println("");
    return forecast;
  }


}